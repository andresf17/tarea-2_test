<?php

namespace src;

class Paciente{
    private $nombre;
    private $apellido;
    private $documento;
    
}
