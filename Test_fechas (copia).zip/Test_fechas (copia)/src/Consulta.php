<?php

namespace src;

class Consulta{
    private $Tipo_paciente;
    private $Tipo_fecha;

    
}